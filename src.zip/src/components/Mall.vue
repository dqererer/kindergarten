<template>
  <div class="header">商城</div>
</template>

<script>
export default {
  name: 'Mall',
  // beforeRouteLeave(to, from, next) {
  //   // console.log(from)
  //   alert('leave');
  //   next()
  // },
  // beforeRouteEnter(to, from, next) {
  //   alert("before");
  //   next()
  // },
  // beforeRouteUpdate(to, from, next) {
  //   alert("update");
  //   next()
  // }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
