<template>
  <div class="header">
    消息
  </div>
</template>

<script>

export default {
  name: 'News'
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
