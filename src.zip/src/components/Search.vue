<template>
  <div class="search">
    12222
  </div>
</template>

<script>
export default {
  name: 'Search',
  data: function(){
    return {
      input2: '',
    }
  }
  
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
input{
  width: 15rem;
  height: 2rem;
  background-color: #2d2c2c14;
  border: 0;
  border-radius: 1rem;
}
input::-ms-input-placeholder{
  text-align: center;
}
input::-webkit-input-placeholder{
  text-align: center;
}

</style>
