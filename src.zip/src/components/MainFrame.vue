<template>
  <div class="main-frame">
    <div class="content">
      <router-view></router-view>
    </div>
    <div class="heaer">
      <Header/>
    </div>
  </div>
</template>

<script>
import Header from './Header'
export default {
  name: 'MainFrame',
  components: {
    Header
  },
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.main-frame{
  height: 100%;
  display: flex;
  flex-direction: column;
}
.main-frame .content{
  flex: 1;
}
.main-frame .header{
  height: 8rem;
}
</style>
