<template>
  <div class="tab">
    <div class="ul">
      <router-link to="./List" v-for="(item,index) in list" v-bind:key="index"  active-class="cur">{{item.title}}</router-link>
    </div>
  </div>
</template>

<script>
// import Search from './Search'
export default {
  name: 'Tab',
  data: function(){
    return {
      list:[
        {
          title:"关注",
        },
        {
          title:"发现",
        },
        {
          title:"北京",
        }
      ],
    }
  },
  methods:{
    
  },
  components: {
    // Search
  },
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.tab{
  height: 2.5rem;
}
.ul{
  width: 45%;
  margin: 0 auto;
  display: flex;
  align-items: center;
  justify-content: space-around;
  padding-inline-start: 0;
}
a{
  color: grey;
}
.cur{
  color: black;
  font-weight: bolder;
  /* text-decoration: underline red; */
  position: relative;
}
.cur::after{
  position: absolute;
  content: "";
  width: 1.5rem;
  height: 0.1rem;
  background-color: red;
  top: 1.5rem;
  left: 0.25rem;
  font-weight: bolder;
}
</style>
