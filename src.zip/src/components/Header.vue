<template>
  <div class="ct">
    <router-link to="/Index">首页</router-link>
    <router-link to="/Mall">商城</router-link>
    <router-link to="/News">消息</router-link>
    <router-link to="/Mine">我的</router-link>
  </div>
</template>

<script>
export default {
  name: 'Header',
  data: function () {
    return {
      // : 0
    }
  },
  methods: {
  },
  created: function () {

  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.ct{
  display: flex;
  justify-content: space-around;
  align-items: center;
}
.ct a{
  text-decoration: none;
  color:black;
  font-size: 1.2rem;
}
.ct .router-link-active{
  font-weight: bold;
}
</style>
