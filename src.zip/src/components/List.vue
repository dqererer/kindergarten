<template>
  <div class="list">
   lllllist 
  </div>
</template>

<script>
// import Search from './Search'
export default {
  name: 'List',
  data: function(){
    return {
     
    }
  },
  methods:{
    
  },
  components: {
    // Search
  },
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
