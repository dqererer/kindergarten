<template>
  <div class="header">
    我的
  </div>
</template>

<script>

export default {
  name: 'Mine'
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
