<template>
  <div class="index">
    <div class="header">
      <tab/>
      <router-link to="./Search" class="demo-input-suffix">
        <el-input placeholder="请输入内容" prefix-icon="el-icon-search" ></el-input>
      </router-link>
      <router-view></router-view>
    </div>
  </div>
</template>

<script>
import Tab from './tab'
export default {
  name: 'Index',
  components: {
    Tab
  },
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.demo-input-suffix >>> .el-input__prefix{
  left: 124px;
}
.demo-input-suffix >>> .el-input__inner{
  width: 80%;
}
.demo-input-suffix >>> .el-input--small .el-input__inner::-ms-input-placeholder{
  text-align: center;
}
.demo-input-suffix /deep/ .el-input--small .el-input__inner::-webkit-input-placeholder{
  text-align: center;
}
</style>
